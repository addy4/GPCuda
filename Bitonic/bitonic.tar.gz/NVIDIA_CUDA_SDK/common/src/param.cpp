#include <param.h>

const Param<int> dummy("error");
